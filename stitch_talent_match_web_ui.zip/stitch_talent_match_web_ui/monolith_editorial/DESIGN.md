---
name: Monolith Editorial
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#444748'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#0041c9'
  on-secondary: '#ffffff'
  secondary-container: '#0356ff'
  on-secondary-container: '#e4e7ff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1c1b1a'
  on-tertiary-container: '#868381'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#dce1ff'
  secondary-fixed-dim: '#b6c4ff'
  on-secondary-fixed: '#001551'
  on-secondary-fixed-variant: '#0039b3'
  tertiary-fixed: '#e6e1df'
  tertiary-fixed-dim: '#cac6c3'
  on-tertiary-fixed: '#1c1b1a'
  on-tertiary-fixed-variant: '#484645'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
  border-hairline: '#E5E5E5'
  match-indicator: '#0055FF'
  text-muted: '#666666'
typography:
  display-xl:
    fontFamily: Hanken Grotesk
    fontSize: 80px
    fontWeight: '800'
    lineHeight: 88px
    letterSpacing: -0.04em
  display-xl-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  section-gap: 120px
---

## Brand & Style

The design system is built on a foundation of **Editorial Minimalism**. It targets an audience of ambitious students and high-tier recruiters who value efficiency, clarity, and a premium aesthetic over decorative fluff. The brand personality is authoritative yet transparent, moving away from the "friendly HR" trope toward a "professional studio" atmosphere.

The visual direction follows a **High-Contrast / Bold** movement, utilizing massive typographic scales and a strictly limited color palette. It leverages a flat design language characterized by hairline strokes, heavy whitespace, and an absence of gradients or skeuomorphic depth. The goal is to make skill-based data feel like a curated gallery rather than a database.

## Colors

The palette is strictly monochrome-first to ensure maximum legibility and an editorial feel.
- **Base:** The primary surface is `#F9F9F9` (Off-white), providing a softer contrast than pure white for long-form reading.
- **Text & Structure:** `#121212` (Near-black) is used for all primary text, borders, and structural elements.
- **Accent:** `#0055FF` (Electric Blue) is the sole "functional" color. It is reserved exclusively for primary actions, match percentages, and active selection states.
- **Success/Warning/Error:** These should be handled through iconography or typographic weight rather than color where possible to maintain the monochrome aesthetic.

## Typography

The typographic system is the primary driver of hierarchy. 
- **Display & Headlines:** Use **Hanken Grotesk**. It provides a sharp, contemporary geometric feel that mimics high-end studio branding. Tighten letter-spacing on larger sizes to create a "dense" editorial look.
- **Body:** **Inter** is used for its exceptional legibility in data-heavy views. It remains neutral, allowing the headlines to shine.
- **Data & Labels:** **JetBrains Mono** is introduced for skill tags, match scores, and metadata. This adds a subtle "technical" layer to the recruitment platform, emphasizing the skill-based nature of the matching.

## Layout & Spacing

This design system utilizes a **Fixed Grid** for desktop and a **Fluid Grid** for mobile. 
- **Desktop:** A 12-column grid with a maximum container width of 1440px. Gutters are kept wide at 24px to maintain an airy feel.
- **Margins:** Aggressive outer margins (64px+) push content toward the center, creating the "studio" look.
- **Vertical Rhythm:** Use a strict 4px/8px base unit. Section gaps are intentionally large (120px+) to allow the eye to rest between different types of information (e.g., between "Candidate Bio" and "Skill Matrix").
- **Mobile:** Reflow to a single column with 16px margins. Headlines should scale down significantly while maintaining their bold weight.

## Elevation & Depth

Depth is achieved through **Tonal Layers** and **Bold Borders** rather than traditional shadows.
- **Surface Strategy:** The background is `#F9F9F9`. Raised elements (cards) use a pure `#FFFFFF` background.
- **Borders:** Hairline borders (1px) in `#E5E5E5` define the boundaries of cards and sections. 
- **Active State Shadow:** For the rare instances where depth is required (e.g., a candidate card being dragged or a hovered action), use a very soft, diffused shadow: `0 10px 30px rgba(0,0,0,0.03)`. It should be almost imperceptible.
- **Match Indicators:** Use the primary accent color (`#0055FF`) to create "depth" through visual prominence rather than Z-axis elevation.

## Shapes

The design system adopts a **Sharp (0)** roundedness strategy. All containers, buttons, and input fields must have square corners. This reinforces the architectural and editorial narrative. 

The only exception to this rule is the "Match Percentage" pill or specialized "Status" chips, which can use a 100% pill shape to differentiate "data points" from "interface elements."

## Components

- **Buttons:** Primary buttons are solid `#121212` with white text. They are perfectly rectangular. Secondary buttons use the hairline border with no background. Hover states for primary buttons should shift to the accent `#0055FF`.
- **Input Fields:** Minimalist. Only a bottom border (2px) in `#E5E5E5`. When active, the border turns `#121212`. Use **JetBrains Mono** for placeholder text.
- **Candidate Cards:** Large white blocks with 1px borders. Headlines should be prominent. Skills are displayed as text-only labels in **JetBrains Mono** separated by slashes (/) or dots (•).
- **Match Indicators:** A bold typographic treatment (e.g., "98% MATCH") in the accent color, using the Display font weight.
- **Lists:** Use generous vertical padding (32px+) between list items with a single-pixel separator stretching the full width of the container.
- **Checkboxes/Radios:** Square and custom-styled to match the 1px border aesthetic. A solid `#121212` fill indicates selection.